module burrito_restaurant {
	requires java.sql;
}