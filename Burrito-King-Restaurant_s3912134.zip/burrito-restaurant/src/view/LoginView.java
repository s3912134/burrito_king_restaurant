package view;

public class LoginView {
    public void renderLoginForm() {
       
        System.out.println("Rendering login form...");
    }

    public void showErrorMessage(String message) {
       
        System.out.println("Error: " + message);
    }
}
